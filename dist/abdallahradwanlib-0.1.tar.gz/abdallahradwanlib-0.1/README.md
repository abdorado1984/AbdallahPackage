# AbdallahPackage
* pip install twine
* pip install setuptools wheel
* pip install tqdm
* python setup.py sdist